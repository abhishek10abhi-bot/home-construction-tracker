package com.example.homeconstructiontracker;
import android.app.*;
import android.os.*;
import android.content.*;
import android.database.*;
import android.database.sqlite.*;
import android.graphics.Color;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.text.*;
import java.util.*;

public class MainActivity extends Activity {
 DB db; LinearLayout root,list; TextView total,balance,me,father,brother,builderView,contractView;
 EditText builderInput,contractInput; Uri pendingReceipt; static final int PICK=101;
 TextView tv(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setPadding(12,9,12,9);return t;}
 Button bt(String s){Button b=new Button(this);b.setText(s);return b;}
 String money(double n){return "₹"+String.format(Locale.US,"%,.0f",n);}
 public void onCreate(Bundle b){super.onCreate(b);db=new DB(this);ui();refresh();}
 void ui(){
  ScrollView sc=new ScrollView(this);root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(14,14,14,100);sc.addView(root);setContentView(sc);
  TextView h=tv("HOME CONSTRUCTION\nPayment Tracker",22);h.setTextColor(Color.WHITE);h.setBackgroundColor(0xff111827);h.setPadding(18,20,18,20);root.addView(h);
  builderView=tv("",17);contractView=tv("",15);root.addView(builderView);root.addView(contractView);
  total=tv("Total Paid: ₹0",22);total.setTextColor(0xff15803d);root.addView(total);
  balance=tv("Balance: ₹0",22);balance.setTextColor(0xffc2410c);root.addView(balance);
  root.addView(tv("Contribution by Family Member",18));
  LinearLayout p=new LinearLayout(this);
  me=tv("ME\n₹0",16);father=tv("FATHER\n₹0",16);brother=tv("BROTHER\n₹0",16);
  p.addView(me,new LinearLayout.LayoutParams(0,-2,1));p.addView(father,new LinearLayout.LayoutParams(0,-2,1));p.addView(brother,new LinearLayout.LayoutParams(0,-2,1));root.addView(p);
  Button add=bt("＋ Add Payment");add.setOnClickListener(v->dialog(null));root.addView(add);
  Button backup=bt("Export Backup");backup.setOnClickListener(v->exportBackup());root.addView(backup);
  root.addView(tv("Payment History",18));list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);root.addView(list);
  root.addView(tv("Builder Settings",18));builderInput=new EditText(this);builderInput.setHint("Builder / Contractor");root.addView(builderInput);
  contractInput=new EditText(this);contractInput.setHint("Contract Value");contractInput.setInputType(2);root.addView(contractInput);
  Button save=bt("Save Builder Details");save.setOnClickListener(v->{db.set("builder",builderInput.getText().toString());db.set("contract",contractInput.getText().toString());refresh();});root.addView(save);
 }
 void refresh(){
  String b=db.get("builder","ABC Builder");double c=Double.parseDouble(db.get("contract","5000000"));
  builderInput.setText(b);contractInput.setText(String.valueOf((long)c));builderView.setText("Builder / Contractor: "+b);contractView.setText("Contract: "+money(c));
  double[] s=db.sums();total.setText("Total Paid: "+money(s[0]));balance.setText("Balance: "+money(Math.max(0,c-s[0])));
  me.setText("ME\n"+money(s[1]));father.setText("FATHER\n"+money(s[2]));brother.setText("BROTHER\n"+money(s[3]));
  list.removeAllViews();Cursor x=db.all();if(!x.moveToFirst()){list.addView(tv("No payments yet.",14));return;}
  do{
   long id=x.getLong(0);String date=x.getString(1),payer=x.getString(2),mode=x.getString(4),stage=x.getString(6),receipt=x.getString(7),utr=x.getString(5);double a=x.getDouble(3);
   LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.addView(tv(payer+" → "+b+"     "+money(a),17));r.addView(tv(date+" · "+mode+" · "+(stage.isEmpty()?"Construction":stage),12));
   if(!utr.isEmpty())r.addView(tv("UTR/Cheque: "+utr,12));
   if(!receipt.isEmpty()){TextView z=tv("📎 Receipt attached — tap to view",12);z.setTextColor(0xff2563eb);z.setOnClickListener(v->viewReceipt(receipt));r.addView(z);}
   LinearLayout act=new LinearLayout(this);Button e=bt("Edit"),d=bt("Delete");e.setOnClickListener(v->dialog(id));d.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Delete payment?").setMessage("This payment will be removed.").setNegativeButton("Cancel",null).setPositiveButton("Delete",(q,w)->{db.del(id);refresh();}).show());act.addView(e,new LinearLayout.LayoutParams(0,-2,1));act.addView(d,new LinearLayout.LayoutParams(0,-2,1));r.addView(act);list.addView(r);
  }while(x.moveToNext());x.close();
 }
 void dialog(Long id){
  LinearLayout f=new LinearLayout(this);f.setOrientation(LinearLayout.VERTICAL);f.setPadding(18,0,18,0);
  EditText date=new EditText(this);date.setHint("Date YYYY-MM-DD");EditText amt=new EditText(this);amt.setHint("Amount ₹");amt.setInputType(2);
  Spinner payer=new Spinner(this);payer.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Me","Father","Brother"}));
  Spinner mode=new Spinner(this);mode.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"UPI","Bank Transfer","Cash","Cheque","NEFT","RTGS"}));
  EditText utr=new EditText(this);utr.setHint("UTR / Cheque Number");EditText stage=new EditText(this);stage.setHint("Work / Stage");EditText rem=new EditText(this);rem.setHint("Remarks");
  Button choose=bt("📎 Select Receipt / Photo / PDF");f.addView(date);f.addView(amt);f.addView(payer);f.addView(mode);f.addView(utr);f.addView(stage);f.addView(choose);f.addView(rem);
  String oldReceipt="";
  if(id!=null){Cursor c=db.one(id);if(c.moveToFirst()){date.setText(c.getString(1));amt.setText(String.valueOf((long)c.getDouble(3)));payer.setSelection(((ArrayAdapter)payer.getAdapter()).getPosition(c.getString(2)));mode.setSelection(((ArrayAdapter)mode.getAdapter()).getPosition(c.getString(4)));utr.setText(c.getString(5));stage.setText(c.getString(6));oldReceipt=c.getString(7);rem.setText(c.getString(8));}c.close();}else date.setText(new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date()));
  pendingReceipt=null;final String existing=oldReceipt;
  choose.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");startActivityForResult(i,PICK);});
  AlertDialog q=new AlertDialog.Builder(this).setTitle(id==null?"Add Payment":"Edit Payment").setView(f).setNegativeButton("Cancel",null).setPositiveButton("Save",null).create();
  q.setOnShowListener(v->q.getButton(-1).setOnClickListener(w->{if(amt.getText().toString().isEmpty()){amt.setError("Required");return;}String rp=existing;if(pendingReceipt!=null)rp=copy(pendingReceipt,id==null?System.currentTimeMillis():id);if(id==null)db.add(date.getText().toString(),payer.getSelectedItem().toString(),Double.parseDouble(amt.getText().toString()),mode.getSelectedItem().toString(),utr.getText().toString(),stage.getText().toString(),rp,rem.getText().toString());else db.upd(id,date.getText().toString(),payer.getSelectedItem().toString(),Double.parseDouble(amt.getText().toString()),mode.getSelectedItem().toString(),utr.getText().toString(),stage.getText().toString(),rp,rem.getText().toString());q.dismiss();refresh();}));q.show();
 }
 String copy(Uri u,long id){try{File d=new File(getFilesDir(),"receipts");d.mkdirs();File o=new File(d,"receipt_"+id);InputStream in=getContentResolver().openInputStream(u);FileOutputStream out=new FileOutputStream(o);byte[] buf=new byte[8192];int n;while((n=in.read(buf))>0)out.write(buf,0,n);in.close();out.close();return o.getAbsolutePath();}catch(Exception e){return "";}}
 void viewReceipt(String p){Intent i=new Intent(Intent.ACTION_VIEW);i.setDataAndType(Uri.parse("file://"+p),"*/*");i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);try{startActivity(i);}catch(Exception e){Toast.makeText(this,"No viewer available",Toast.LENGTH_SHORT).show();}}
 public void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==PICK&&c==RESULT_OK&&d!=null)pendingReceipt=d.getData();}
 void exportBackup(){try{File o=new File(getExternalFilesDir(null),"home_construction_backup.json");FileWriter w=new FileWriter(o);w.write(db.json());w.close();Toast.makeText(this,"Backup saved: "+o.getAbsolutePath(),Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"Backup failed",Toast.LENGTH_SHORT).show();}}
 class DB extends SQLiteOpenHelper{
  DB(Context c){super(c,"construction.db",null,1);}public void onCreate(SQLiteDatabase d){d.execSQL("CREATE TABLE payments(id INTEGER PRIMARY KEY AUTOINCREMENT,date TEXT,payer TEXT,amount REAL,mode TEXT,utr TEXT,stage TEXT,receipt TEXT,remarks TEXT)");d.execSQL("CREATE TABLE settings(k TEXT PRIMARY KEY,v TEXT)");}public void onUpgrade(SQLiteDatabase d,int a,int b){}
  void set(String k,String v){getWritableDatabase().execSQL("INSERT OR REPLACE INTO settings(k,v) VALUES(?,?)",new Object[]{k,v});}String get(String k,String def){Cursor c=getReadableDatabase().rawQuery("SELECT v FROM settings WHERE k=?",new String[]{k});String v=def;if(c.moveToFirst())v=c.getString(0);c.close();return v;}
  void add(String da,String p,double a,String m,String u,String s,String r,String re){ContentValues v=cv(da,p,a,m,u,s,r,re);getWritableDatabase().insert("payments",null,v);}void upd(long id,String da,String p,double a,String m,String u,String s,String r,String re){getWritableDatabase().update("payments",cv(da,p,a,m,u,s,r,re),"id=?",new String[]{""+id});}ContentValues cv(String da,String p,double a,String m,String u,String s,String r,String re){ContentValues v=new ContentValues();v.put("date",da);v.put("payer",p);v.put("amount",a);v.put("mode",m);v.put("utr",u);v.put("stage",s);v.put("receipt",r);v.put("remarks",re);return v;}void del(long id){getWritableDatabase().delete("payments","id=?",new String[]{""+id});}Cursor all(){return getReadableDatabase().rawQuery("SELECT * FROM payments ORDER BY id",null);}Cursor one(long id){return getReadableDatabase().rawQuery("SELECT * FROM payments WHERE id=?",new String[]{""+id});}
  double[] sums(){double[] a=new double[4];Cursor c=all();while(c.moveToNext()){double n=c.getDouble(3);a[0]+=n;if(c.getString(2).equals("Me"))a[1]+=n;else if(c.getString(2).equals("Father"))a[2]+=n;else a[3]+=n;}c.close();return a;}
  String json(){StringBuilder s=new StringBuilder("{\"builder\":\""+get("builder","ABC Builder")+"\",\"contract\":\""+get("contract","5000000")+"\",\"payments\":[");Cursor c=all();boolean f=true;while(c.moveToNext()){if(!f)s.append(",");f=false;s.append("{\"date\":\"").append(c.getString(1)).append("\",\"payer\":\"").append(c.getString(2)).append("\",\"amount\":").append(c.getDouble(3)).append(",\"mode\":\"").append(c.getString(4)).append("\",\"utr\":\"").append(c.getString(5)).append("\",\"stage\":\"").append(c.getString(6)).append("\",\"receipt\":\"").append(c.getString(7)).append("\",\"remarks\":\"").append(c.getString(8)).append("\"}");}c.close();return s.append("]}").toString();}
 }
}

Home Construction Tracker v2 — native Android app.
Uses Android SQLite local database instead of Chrome localStorage. Receipts are copied into app-private storage. Includes add/edit/delete payments, payer totals, builder balance, receipt attachment/viewing, and backup export.
